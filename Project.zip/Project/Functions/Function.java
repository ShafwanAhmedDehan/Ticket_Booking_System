package Functions;
import java.lang.*;
import java.util.*;
import Vehicle.*;
import Admin.*;
import Passanger.*;

abstract public class Function
{
	abstract public int Payment(int p);
}